// Copyright (c) 2017, sathishpy@gmail.com and contributors
// For license information, please see license.txt

frappe.ui.form.on('Bank Statement Settings', {
	refresh: function(frm) {

	}
});
