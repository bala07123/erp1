# -*- coding: utf-8 -*-
from __future__ import unicode_literals
#from . import __version__ as app_version
from frappe import _

app_name = "iffl"
app_title = "Iffl"
app_publisher = "lserp"
app_description = "iff"
app_icon = "octicon octicon-file-directory"
app_color = "grey"
app_email = "balamurugan.a@lyncspace.com"
app_license = "MIT"
fixtures = ["Custom Field","Custom Script"]
app_logo_url = '/assets/iffl/images/iff logo1.png'

develop_version = '0.x.x-develop'

# Includes in <head>
# ------------------

# include js, css files in header of desk.html
# app_include_css = "/assets/iffl/css/iffl.css"
# app_include_js = "/assets/iffl/js/iffl.js"

# include js, css files in header of web template
# web_include_css = "/assets/iffl/css/iffl.css"
# web_include_js = "/assets/iffl/js/iffl.js"


# include js in page
# page_js = {"page" : "public/js/file.js"}

# include js in doctype views
# doctype_js = {"doctype" : "public/js/doctype.js"}
# doctype_list_js = {"doctype" : "public/js/doctype_list.js"}
# doctype_tree_js = {"doctype" : "public/js/doctype_tree.js"}
# doctype_calendar_js = {"doctype" : "public/js/doctype_calendar.js"}

# Home Pages
# ----------

# application home page (will override Website Settings)
# home_page = "login"

# website user home page (by Role)
# role_home_page = {
#	"Role": "home_page"
# }
website_context = {
	"favicon": 	"/assets/iffl/images/iff logo1.png",
	"splash_image": "/assets/iffl/images/iff logo1.png"
}
website_route_rules = [
	{"from_route": "/orders", "to_route": "Sales Order"},
	{"from_route": "/orders/<path:name>", "to_route": "order",
		"defaults": {
			"doctype": "Sales Order",
			"parents": [{"label": _("Orders"), "route": "orders"}]
		}
	},
	{"from_route": "/invoices", "to_route": "Sales Invoice"},
	{"from_route": "/invoices/<path:name>", "to_route": "order",
		"defaults": {
			"doctype": "Sales Invoice",
			"parents": [{"label": _("Invoices"), "route": "invoices"}]
		}
	},
	{"from_route": "/supplier-quotations", "to_route": "Supplier Quotation"},
	{"from_route": "/supplier-quotations/<path:name>", "to_route": "order",
		"defaults": {
			"doctype": "Supplier Quotation",
			"parents": [{"label": _("Supplier Quotation"), "route": "supplier-quotations"}]
		}
	},
	{"from_route": "/purchase-orders", "to_route": "Purchase Order"},
	{"from_route": "/purchase-orders/<path:name>", "to_route": "order",
		"defaults": {
			"doctype": "Purchase Order",
			"parents": [{"label": _("Purchase Order"), "route": "purchase-orders"}]
		}
	},
	{"from_route": "/purchase-invoices", "to_route": "Purchase Invoice"},
	{"from_route": "/purchase-invoices/<path:name>", "to_route": "order",
		"defaults": {
			"doctype": "Purchase Invoice",
			"parents": [{"label": _("Purchase Invoice"), "route": "purchase-invoices"}]
		}
	},
	{"from_route": "/quotations", "to_route": "Quotation"},
	{"from_route": "/quotations/<path:name>", "to_route": "order",
		"defaults": {
			"doctype": "Quotation",
			"parents": [{"label": _("Quotations"), "route": "quotations"}]
		}
	},
	{"from_route": "/shipments", "to_route": "Delivery Note"},
	{"from_route": "/shipments/<path:name>", "to_route": "order",
		"defaults": {
			"doctype": "Delivery Note",
			"parents": [{"label": _("Shipments"), "route": "shipments"}]
		}
	},
	{"from_route": "/rfq", "to_route": "Request for Quotation"},
	{"from_route": "/rfq/<path:name>", "to_route": "rfq",
		"defaults": {
			"doctype": "Request for Quotation",
			"parents": [{"label": _("Request for Quotation"), "route": "rfq"}]
		}
	},
	{"from_route": "/addresses", "to_route": "Address"},
	{"from_route": "/addresses/<path:name>", "to_route": "addresses",
		"defaults": {
			"doctype": "Address",
			"parents": [{"label": _("Addresses"), "route": "addresses"}]
		}
	},
	{"from_route": "/jobs", "to_route": "Job Opening"},
	{"from_route": "/admissions", "to_route": "Student Admission"},
	{"from_route": "/boms", "to_route": "BOM"},
	{"from_route": "/timesheets", "to_route": "Timesheet"},
	{"from_route": "/material-requests", "to_route": "Material Request"},
	{"from_route": "/material-requests/<path:name>", "to_route": "material_request_info",
		"defaults": {
			"doctype": "Material Request",
			"parents": [{"label": _("Material Request"), "route": "material-requests"}]
		}
	},
]
regional_overrides = {
	'France': {
		'iffl.tests.test_regional.test_method': 'iffl.regional.france.utils.test_method'
	},
	'India': {
		'iffl.tests.test_regional.test_method': 'iffl.regional.india.utils.test_method',
		'iffl.controllers.taxes_and_totals.get_itemised_tax_breakup_header': 'iffl.regional.india.utils.get_itemised_tax_breakup_header',
		'iffl.controllers.taxes_and_totals.get_itemised_tax_breakup_data': 'iffl.regional.india.utils.get_itemised_tax_breakup_data',
		'iffl.accounts.party.get_regional_address_details': 'iffl.regional.india.utils.get_regional_address_details',
		'iffl.hr.utils.calculate_annual_eligible_hra_exemption': 'iffl.regional.india.utils.calculate_annual_eligible_hra_exemption',
		'iffl.hr.utils.calculate_hra_exemption_for_period': 'iffl.regional.india.utils.calculate_hra_exemption_for_period'
	},
	'United Arab Emirates': {
		'iffl.controllers.taxes_and_totals.update_itemised_tax_data': 'iffl.regional.united_arab_emirates.utils.update_itemised_tax_data'
	},
	'Saudi Arabia': {
		'iffl.controllers.taxes_and_totals.update_itemised_tax_data': 'iffl.regional.united_arab_emirates.utils.update_itemised_tax_data'
	},
	'Italy': {
		'iffl.controllers.taxes_and_totals.update_itemised_tax_data': 'iffl.regional.italy.utils.update_itemised_tax_data',
		'iffl.controllers.accounts_controller.validate_regional': 'iffl.regional.italy.utils.sales_invoice_validate',
	}
}

# Website user home page (by function)
# get_website_user_home_page = "iffl.utils.get_home_page"

# Generators
# ----------

# automatically create page for each record of this doctype
# website_generators = ["Web Page"]

# Installation
# ------------

# before_install = "iffl.install.before_install"
# after_install = "iffl.install.after_install"

# Desk Notifications
# ------------------
# See frappe.core.notifications.get_notification_config

# notification_config = "iffl.notifications.get_notification_config"

# Permissions
# -----------
# Permissions evaluated in scripted ways

# permission_query_conditions = {
# 	"Event": "frappe.desk.doctype.event.event.get_permission_query_conditions",
# }
#
# has_permission = {
# 	"Event": "frappe.desk.doctype.event.event.has_permission",
# }

# Document Events
# ---------------
# Hook on document methods and events

doc_events = {
# 	"*": {
# 		"on_update": "method",
# 		"on_cancel": "method",
# 		"on_trash": "method"
#	}
	"Sales Invoice": {
		"on_submit": ["iffl.regional.create_transaction_log", "iffl.regional.italy.utils.sales_invoice_on_submit"],
		"on_cancel": "iffl.regional.italy.utils.sales_invoice_on_cancel",
		"on_trash": "iffl.regional.check_deletion_permission"
	},
	('Sales Invoice', 'Sales Order', 'Delivery Note', 'Purchase Invoice', 'Purchase Order', 'Purchase Receipt'): {
		'validate': ['iffl.regional.india.utils.set_place_of_supply']
	},

 }

# Scheduled Tasks
# ---------------

# scheduler_events = {
# 	"all": [
# 		"iffl.tasks.all"
# 	],
# 	"daily": [
# 		"iffl.tasks.daily"
# 	],
# 	"hourly": [
# 		"iffl.tasks.hourly"
# 	],
# 	"weekly": [
# 		"iffl.tasks.weekly"
# 	]
# 	"monthly": [
# 		"iffl.tasks.monthly"
# 	]
# }

# Testing
# -------

# before_tests = "iffl.install.before_tests"

# Overriding Methods
# ------------------------------
#
# override_whitelisted_methods = {
# 	"frappe.desk.doctype.event.event.get_events": "iffl.event.get_events"
# }
#
# each overriding function accepts a `data` argument;
# generated from the base implementation of the doctype dashboard,
# along with any modifications made in other Frappe apps
# override_doctype_dashboards = {
# 	"Task": "iffl.task.get_dashboard_data"
# }

