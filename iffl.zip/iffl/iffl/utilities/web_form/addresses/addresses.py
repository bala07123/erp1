from __future__ import unicode_literals

import frappe

def get_context(context):
	# do your magic here
	context.show_sidebar = True
