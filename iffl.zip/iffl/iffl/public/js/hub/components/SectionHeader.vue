<template>
    <div class="hub-items-header level"><slot></slot></div>
</template>
