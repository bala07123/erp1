/* Saving this for later */
<template>
	<div class="media timeline-item  notification-content">
		<div class="small">
			<i class="octicon octicon-bookmark fa-fw"></i>
			<span title="Administrator"><b>4 weeks ago</b> Published 1 item to Marketplace</span>
		</div>
	</div>
</template>
